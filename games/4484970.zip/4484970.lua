-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 4484970.lua
--Gamename Wallpaper Animator
addappid(4484970) --Mainappid Wallpaper Animator
addappid(4484971, 1, "3fba67e423e03a0c88e0e228b0694bd35fa03b47726dde9afb7d6f4dc88cbfb1") --Main Windows Depot Wallpaper Animator
setManifestid(4484971, "7352655064019974519", 49327264)