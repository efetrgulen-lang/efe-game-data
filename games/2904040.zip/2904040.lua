-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 2904040.lua
addappid(2904040)
addappid(2904041, 1, "5f2fc48115edd9e7bfc1546f9dc43c8d900013aaf3d4f5035fb69ff28899f050")
setManifestid(2904041, "8872870141594499423", 3653535616)