-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 4286120.lua
addappid(4286120)
addappid(4286121, 1, "8ba184028e7c93e71bf1be655408324148b30e3f1201b728dc7dbac93a581fe1")
setManifestid(4286121, "7616877999076085544", 807762176)