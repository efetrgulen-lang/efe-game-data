-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 3643170.lua
addappid(3643170, 1, "489dc625b46f28cdb73ac15226c22e793cf580ad0e737df89623e257bb6a609c")
addappid(3643171, 1, "7d044644abebe1ae2cc08b7c0f2e4bb004c3616d81ffe2b4bf0e8ed2107fda67")
setManifestid(3643171, "4719770257904384767", 743183968)