-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 4324480.lua
--gamename Dirty Business
addappid(4324480, 1, "01ba04adf015365a20ef646239cef96ee73af65f613f36aa4a14b9586576c6e7") --mainappid Dirty Business
addappid(4324481, 1, "c5df4573fdf1724349b33953fdf5ddcaa8ad0d98180aa74bf5ff92f38c5376de") --maindepot Dirty Business
setManifestid(4324481, "6281822995454056743", 3970076496)