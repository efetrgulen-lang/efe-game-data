-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 3501070.lua
addappid(3501070, 1, "e2342efc9b3a360291be146a6be30d7b129bbdad5900b09806483c244ab607cb")
addappid(3501071, 1, "7bb00da72e348f52d382147b41332f518de67a4ff8f3ab8cd203888982e72de4")
setManifestid(3501071, "1980243417666500400", 2677611088)