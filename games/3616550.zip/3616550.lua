-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 3616550.lua
addappid(3616550)
addappid(3616551, 1, "321f51821758384501bec04ad6a82ad3bab317a8de1b00971de7161775883c48")
setManifestid(3616551, "6732519671173135267", 2146842864)